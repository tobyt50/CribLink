// src/config.js
const API_BASE_URL = "http://localhost:5000";

export default API_BASE_URL;
