import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  LogIn,
  Settings,
  UserPlus,
  User,
  LogOut,
  LayoutDashboard,
} from "lucide-react";
import { useTheme } from "../layouts/AppShell";
import { useMessage } from '../context/MessageContext';
import { useAuth } from '../context/AuthContext'; // <--- NEW IMPORT

function ProfileMenu({ onCloseMobileHeaderMenu }) { // Removed 'user' prop as it comes from context
  const [showMenu, setShowMenu] = useState(false);
  const menuRef = useRef(null);
  const navigate = useNavigate();
  const { darkMode } = useTheme();
  const { showMessage } = useMessage();
  const { user, logout } = useAuth(); // <--- Get user and logout from AuthContext

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setShowMenu(false);
      }
    };

    const handleEscape = (e) => {
      if (e.key === "Escape") {
        setShowMenu(false);
      }
    };

    if (showMenu) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleEscape);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [showMenu]);

  // Handles user logout using the logout function from AuthContext
  const handleLogout = () => {
    logout(); // Call logout from AuthContext
    setShowMenu(false);
    onCloseMobileHeaderMenu && onCloseMobileHeaderMenu(false);
    navigate("/signin");
    showMessage('You have been logged out.', 'info', 3000);
  };

  const handleDashboardRedirect = () => {
    if (!user?.role) return;
    const role = user.role.toLowerCase();
    if (["admin", "agent", "client"].includes(role)) {
      navigate(`/${role}/dashboard`);
      setShowMenu(false);
      onCloseMobileHeaderMenu && onCloseMobileHeaderMenu(false);
    }
  };

  const menuVariants = {
    hidden: { opacity: 0, y: -20, scale: 0.95 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 500,
        damping: 30,
        delayChildren: 0.1,
        staggerChildren: 0.05,
      },
    },
    exit: { opacity: 0, y: -20, scale: 0.95, transition: { duration: 0.2, ease: "easeOut" } },
  };

  const itemVariants = {
    hidden: { y: 10, opacity: 0 },
    visible: { y: 0, opacity: 1 },
  };

  return (
    <div className="relative flex items-center gap-2" ref={menuRef}>
      <button
        onClick={() => setShowMenu((prev) => !prev)}
        className={`flex items-center gap-2 transition-all duration-300 ease-in-out focus:outline-none
          ${darkMode ? "text-gray-200 hover:text-yellow-300" : "text-white hover:text-yellow-300"}`}
      >
        {user ? (
          <>
            <div className="bg-gradient-to-br from-green-500 to-green-700 text-white w-9 h-9 rounded-full flex items-center justify-center font-bold text-base shadow-md">
              {user.full_name?.charAt(0).toUpperCase() || "U"}
            </div>
            <span className={`text-sm font-semibold hidden md:inline ${darkMode ? "text-gray-200" : "text-white"}`}>
              {user.full_name?.split(" ")[0]}
            </span>
          </>
        ) : (
          <User className={`w-7 h-7 ${darkMode ? "text-gray-200" : "text-white"}`} />
        )}
        <motion.div
          animate={{ rotate: showMenu ? 180 : 0 }}
          transition={{ duration: 0.2 }}
          className="hidden md:block"
        >
          <ChevronDown className={`w-5 h-5 ${darkMode ? "text-gray-200" : "text-white"}`} />
        </motion.div>

        <motion.div
          initial={false}
          animate={{ x: 0 }}
          transition={{ duration: 0.2 }}
          className="block md:hidden"
        >
          {showMenu ? (
            <ChevronRight className={`w-5 h-5 ${darkMode ? "text-gray-200" : "text-white"}`} />
          ) : (
            <ChevronLeft className={`w-5 h-5 ${darkMode ? "text-gray-200" : "text-white"}`} />
          )}
        </motion.div>
      </button>

      <AnimatePresence>
        {showMenu && (
          <motion.div
            className="flex items-center gap-5 md:hidden"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
          >
            {user ? (
              <>
                <motion.button
                  whileHover={{ x: 5 }}
                  onClick={handleDashboardRedirect}
                  className={`flex items-center gap-1 text-sm font-medium transition-colors duration-200
                    ${darkMode ? "text-gray-200 hover:text-yellow-300" : "text-white hover:text-yellow-300"}`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  <span>Dashboard</span>
                </motion.button>

                <motion.div whileHover={{ x: 5 }}>
                  <Link
                    to="/profile/general"
                    className={`flex items-center gap-1 text-sm font-medium transition-colors duration-200
                      ${darkMode ? "text-gray-200 hover:text-yellow-300" : "text-white hover:text-yellow-300"}`}
                    onClick={() => {
                      setShowMenu(false);
                      onCloseMobileHeaderMenu && onCloseMobileHeaderMenu(false);
                    }}
                  >
                    <Settings className="w-4 h-4" />
                    <span>Profile</span>
                  </Link>
                </motion.div>

                <motion.button
                  whileHover={{ x: 5 }}
                  onClick={handleLogout}
                  className={`flex items-center gap-1 text-sm font-medium transition-colors duration-200
                    ${darkMode ? "text-gray-200 hover:text-red-300" : "text-white hover:text-red-300"}`}
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </motion.button>
              </>
            ) : (
              <>
                <motion.div whileHover={{ x: 5 }}>
                  <Link
                    to="/signin"
                    className={`flex items-center gap-1 text-sm font-medium transition-colors duration-200
                      ${darkMode ? "text-gray-200 hover:text-yellow-300" : "text-white hover:text-yellow-300"}`}
                    onClick={() => {
                      setShowMenu(false);
                      onCloseMobileHeaderMenu && onCloseMobileHeaderMenu(false);
                    }}
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Login</span>
                  </Link>
                </motion.div>

                <motion.div whileHover={{ x: 5 }}>
                  <Link
                    to="/select-role"
                    className={`flex items-center gap-1 text-sm font-medium transition-colors duration-200
                      ${darkMode ? "text-gray-200 hover:text-yellow-300" : "text-white hover:text-yellow-300"}`}
                    onClick={() => {
                      setShowMenu(false);
                      onCloseMobileHeaderMenu && onCloseMobileHeaderMenu(false);
                    }}
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>Sign Up</span>
                  </Link>
                </motion.div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showMenu && (
          <motion.div
            variants={menuVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            className={`absolute right-0 top-full mt-4 w-60 border rounded-xl shadow-xl py-2 z-50 overflow-hidden transform origin-top-right hidden md:block
              ${darkMode ? "bg-gray-800 text-gray-200 border-gray-700" : "bg-white text-green-800 border-gray-200"}`}
          >
            {user ? (
              <>
                <div className={`px-4 py-2 text-xs uppercase tracking-wider border-b mb-1
                  ${darkMode ? "text-gray-400 border-gray-700" : "text-gray-500 border-gray-100"}`}>
                  {user.role}
                </div>

                <motion.button
                  variants={itemVariants}
                  whileHover={{ x: 5 }}
                  onClick={handleDashboardRedirect}
                  className={`w-full text-left flex items-center gap-3 px-4 py-2 text-sm font-medium transition-colors duration-200
                    ${darkMode ? "text-gray-200 hover:bg-gray-700" : "text-gray-700 hover:bg-green-50 hover:text-green-700"}`}
                >
                  <LayoutDashboard className="w-4 h-4" /> Dashboard
                </motion.button>

                <motion.div variants={itemVariants} whileHover={{ x: 5 }}>
                  <Link
                    to="/profile/general"
                    className={`flex items-center gap-3 px-4 py-2 text-sm font-medium transition-colors duration-200
                      ${darkMode ? "text-gray-200 hover:bg-gray-700" : "text-gray-700 hover:bg-green-50 hover:text-green-700"}`}
                    onClick={() => setShowMenu(false)}
                  >
                    <Settings className="w-4 h-4" /> Manage Profile
                  </Link>
                </motion.div>

                <motion.button
                  variants={itemVariants}
                  whileHover={{ x: 5 }}
                  onClick={handleLogout}
                  className={`w-full text-left flex items-center gap-3 px-4 py-2 text-sm font-medium transition-colors duration-200
                    ${darkMode ? "text-gray-200 hover:bg-gray-700 hover:text-red-300" : "text-gray-700 hover:bg-red-50 hover:text-red-600"}`}
                >
                  <LogOut className="w-4 h-4" /> Log Out
                </motion.button>
              </>
            ) : (
              <>
                <motion.div variants={itemVariants} whileHover={{ x: 5 }}>
                  <Link
                    to="/signin"
                    className={`flex items-center gap-3 px-4 py-2 text-sm font-medium transition-colors duration-200
                      ${darkMode ? "text-gray-200 hover:bg-gray-700" : "text-gray-700 hover:bg-green-50 hover:text-green-700"}`}
                    onClick={() => setShowMenu(false)}
                  >
                    <LogIn className="w-4 h-4" /> Login
                  </Link>
                </motion.div>

                <motion.div variants={itemVariants} whileHover={{ x: 5 }}>
                  <Link
                    to="/select-role"
                    className={`flex items-center gap-3 px-4 py-2 text-sm font-medium transition-colors duration-200
                      ${darkMode ? "text-gray-200 hover:bg-gray-700" : "text-gray-700 hover:bg-green-50 hover:text-green-700"}`}
                    onClick={() => setShowMenu(false)}
                  >
                    <UserPlus className="w-4 h-4" /> Create Account
                  </Link>
                </motion.div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default ProfileMenu;
