// AuthContext.js
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { jwtDecode } from 'jwt-decode';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const decodeAndSetUser = useCallback((token) => {
    if (token) {
      try {
        const decodedToken = jwtDecode(token);
        const currentTime = Date.now() / 1000;

        if (decodedToken.exp > currentTime) {
          // Attempt to get the full user object from localStorage if available
          const storedUser = JSON.parse(localStorage.getItem('user')); //

          setUser({
            user_id: decodedToken.user_id,
            full_name: decodedToken.name,
            email: decodedToken.email,
            role: decodedToken.role,
            status: decodedToken.status,
            // Include default_landing_page from storedUser if it exists
            default_landing_page: storedUser?.default_landing_page || null, //
            // Add any other fields you store in localStorage 'user' object here
          });
        } else {
          console.log("Token expired during sync. Clearing user data.");
          localStorage.removeItem("token");
          localStorage.removeItem("user"); // Clear user from localStorage too
          setUser(null);
        }
      } catch (error) {
        console.error("Invalid token during sync:", error);
        localStorage.removeItem("token");
        localStorage.removeItem("user"); // Clear user from localStorage too
        setUser(null);
      }
    } else {
      setUser(null);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("token");
    decodeAndSetUser(token);

    const handleStorageChange = (event) => {
      if (event.key === 'token' || !event.key) {
        decodeAndSetUser(localStorage.getItem('token'));
      }
    };

    const handleAuthChange = () => {
      decodeAndSetUser(localStorage.getItem('token'));
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('authChange', handleAuthChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('authChange', handleAuthChange);
    };
  }, [decodeAndSetUser]);

  const logout = useCallback(() => {
    console.log('Logging out user from AuthContext.');
    localStorage.removeItem('token');
    localStorage.removeItem('user'); // Ensure user is removed on logout
    setUser(null);
    window.dispatchEvent(new Event('authChange'));
  }, []);

  const authContextValue = {
    user,
    isAuthenticated: !!user,
    loading,
    logout,
  };

  return (
    <AuthContext.Provider value={authContextValue}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};